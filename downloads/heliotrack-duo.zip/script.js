const panels = document.querySelectorAll('.panel');
const observer = new IntersectionObserver(
  entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
      }
    });
  },
  { threshold: 0.2 }
);

panels.forEach(panel => observer.observe(panel));

const navLinks = document.querySelectorAll('.nav a');
const sections = [...document.querySelectorAll('main section')];

window.addEventListener('scroll', () => {
  const scrollPos = window.scrollY + 120;
  let current = sections[0].id;

  sections.forEach(section => {
    if (scrollPos >= section.offsetTop) {
      current = section.id;
    }
  });

  navLinks.forEach(link => {
    const href = link.getAttribute('href').replace('#', '');
    link.classList.toggle('active', href === current);
  });
});
